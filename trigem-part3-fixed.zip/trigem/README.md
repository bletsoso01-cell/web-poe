# TRIGEM Institute of Excellence – Website (Part 3)

A multi-page website for **TRIGEM Institute of Excellence**, a non-profit offering after-school tutoring, mentorship and career guidance to Grade 4–12 learners in Sterkspruit, Eastern Cape.

**Live site:** _add your Netlify / GitHub Pages URL here_  
**Repository:** _add your GitHub URL here_

## Pages
| File | Purpose |
|---|---|
| `index.html` | Home: the original Part 2 one-page layout (hero, about, services, events, success stories, donate, contact) with a working donation and contact form |
| `about.html` | Story, vision / mission / audience tabs, FAQ accordion |
| `services.html` | Programmes rendered by JS with search, category filter and sort |
| `events.html` | Events table rendered by JS with search, filter, sort and a details modal |
| `gallery.html` | Image gallery with lightbox (keyboard and button navigation) |
| `enquiry.html` | Validated enquiry form that returns a cost and availability response |
| `contact.html` | Validated contact form that compiles an email, plus Leaflet map |
| `404.html`, `robots.txt`, `sitemap.xml`, `_headers` | Error page, crawler rules, sitemap, security/caching headers |

## Technologies
HTML5, CSS3 (custom properties, grid, flexbox, animations), JavaScript (ES5/ES6), jQuery 3.7.1 (accordion, tabs), Leaflet 1.9.4 + OpenStreetMap (map).

## JavaScript features
- **Interactive elements:** jQuery accordion and keyboard-accessible tabs, modal dialog, lightbox.
- **Map:** Leaflet map with marker and popup on the contact page.
- **Animations:** CSS transitions, fade-in on scroll (IntersectionObserver), animated counters, card hover effects (disabled for `prefers-reduced-motion`).
- **DOM manipulation:** elements created with `createElement`, event delegation on tables and galleries, dynamically created back-to-top button and dialogs.
- **Dynamic content and search:** programmes, events and gallery are rendered from `js/data.js` (`data/programmes.json` is fetched by the enquiry form).
- **Forms:** HTML5 validation attributes (`required`, `pattern`, `min`, `max`, `minlength`, `maxlength`, `type`) plus JavaScript validation with inline error messages, honeypot spam field and AJAX (`fetch`) in the enquiry form.

## SEO
**On-page:** keyword-focused titles and meta descriptions per page (keywords: *after-school tutoring Sterkspruit, mentorship Eastern Cape, career guidance Grade 4–12, non-profit education South Africa*); one `h1` per page with `h2`/`h3` hierarchy; descriptive image filenames and alt text; clean lowercase URLs; internal links in header, footer and body; mobile-first responsive layout; canonical tags; Open Graph/Twitter tags; `NGO` JSON-LD with address and geo (local SEO).  
**Off-page (plan):** register on Google Business Profile with the Sterkspruit address; request backlinks from schools, local municipality pages, NPO directories and sponsor sites; share events on the Facebook, Instagram, X and LinkedIn pages linked in the footer; encourage reviews and tagged posts.  
**Technical:** `robots.txt`, `sitemap.xml`, no render-blocking third-party fonts or Tailwind CDN, lazy-loaded images with width/height, cache headers, SVG images.  
**Security:** Content-Security-Policy meta tag, `_headers` (X-Frame-Options, nosniff, HSTS, Referrer-Policy), all user-supplied text written with `textContent` (no `innerHTML`), `rel="noopener noreferrer"` on external links, honeypot field.

## Deployment
Deployed from the repository root with Netlify (drag-and-drop or "Import from Git", publish directory `/`) or GitHub Pages (Settings > Pages > Deploy from branch `main` / root). After deploying, replace `https://trigem-institute.netlify.app` in the HTML, `robots.txt` and `sitemap.xml` with the real URL.

## Changelog
> Add one entry per Part 2 feedback point from your lecturer, then keep the entries below.

### Part 3 changes
| # | Area | Change | Reason |
|---|---|---|---|
| 1 | Structure | Converted the single `Index.html` page into 7 linked pages and renamed it `index.html` | Matches the brief (`enquiry.html`, `contact.html`), better navigation and SEO, lowercase clean URL |
| 2 | HTML | Added `<!DOCTYPE html>`, `lang="en-ZA"`, skip link, semantic landmarks, `caption`/`scope` on tables | The original had no doctype; improves validity and accessibility |
| 3 | CSS | Rewrote `style.css`; the original file was corrupted (a comment swallowed the first rules and rules were out of order) and depended on the Tailwind CDN. Removed the Tailwind CDN and Font Awesome | Fixes broken styling, faster loading, fewer third-party dependencies |
| 4 | Content | Updated event dates from 2024 to upcoming dates and the footer year to 2026 | Dates were out of date |
| 5 | Images | Kept the original hosted photos (hero, programme icons, success stories) with descriptive alt text, added width/height and lazy loading, and reused them in the gallery | Image SEO, layout stability, page speed |
| 6 | Forms | Replaced the placeholder `action="#"` donation/contact forms with the validated enquiry and contact forms | Required by Part 3 section 4 |
| 7 | JavaScript | Added accordion, tabs, modal, lightbox, map, animations, dynamic content and search | Required by Part 3 section 2 |
| 10 | Home page | Kept the original Part 2 home page layout and wording; restored Success Stories, Donate and Contact sections, now with validated forms | Preserves the approved design |
| 8 | SEO | Added meta tags, canonical links, JSON-LD, `robots.txt`, `sitemap.xml` | Required by Part 3 section 3 |
| 9 | Security / speed | Added CSP, `_headers`, lazy loading, cache rules | Required by Part 3 section 3.3 |

## Notes
Programme prices, seat numbers and event details are sample data for demonstration. Social media links point to each platform's home page until real accounts are created.
