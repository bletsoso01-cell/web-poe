/* TRIGEM - main.js: navigation, jQuery widgets, dynamic content, forms, map */
(function ($) {
  'use strict';
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var el = function (tag, attrs, text) { var e = document.createElement(tag); Object.keys(attrs || {}).forEach(function (k) { e.setAttribute(k, attrs[k]); }); if (text) e.textContent = text; return e; };
  var fmtDate = function (d) { return new Date(d + 'T00:00:00').toLocaleDateString('en-ZA', { day: 'numeric', month: 'long', year: 'numeric' }); };
  var rand = function (n) { return 'R' + n.toLocaleString('en-ZA'); };

  /* ---------- Navigation: mobile toggle + active link ---------- */
  var btn = document.getElementById('menu-btn'), nav = document.getElementById('site-nav');
  btn.addEventListener('click', function () { btn.setAttribute('aria-expanded', nav.classList.toggle('open')); });
  var here = (location.pathname.split('/').pop() || 'index').replace('.html', '') || 'index';
  $$('#site-nav a').forEach(function (a) { if (a.getAttribute('href').replace('.html', '') === here) a.setAttribute('aria-current', 'page'); });

  /* ---------- DOM: back-to-top button created dynamically, scroll reveal, counters ---------- */
  var top = el('button', { id: 'to-top', 'aria-label': 'Back to top' }, '\u2191');
  document.body.appendChild(top);
  top.addEventListener('click', function () { window.scrollTo({ top: 0 }); });
  window.addEventListener('scroll', function () { top.classList.toggle('show', window.scrollY > 400); }, { passive: true });

  function countUp(e) {
    var end = +e.dataset.count, t0 = null;
    (function step(t) { t0 = t0 || t; var p = Math.min((t - t0) / 1500, 1); e.textContent = Math.floor(p * end) + (e.dataset.suffix || ''); if (p < 1) requestAnimationFrame(step); })(performance.now());
  }
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (items) {
      items.forEach(function (i) { if (i.isIntersecting) { i.target.classList.add('visible'); if (i.target.dataset.count) countUp(i.target); io.unobserve(i.target); } });
    }, { threshold: 0.15 });
    $$('.reveal, [data-count]').forEach(function (e) { io.observe(e); });
  } else { $$('.reveal').forEach(function (e) { e.classList.add('visible'); }); $$('[data-count]').forEach(function (e) { e.textContent = e.dataset.count + (e.dataset.suffix || ''); }); }

  /* ---------- jQuery accordion ---------- */
  $('.acc-btn').on('click', function () {
    var $b = $(this), open = $b.attr('aria-expanded') === 'true';
    $b.closest('.accordion').find('.acc-btn').attr('aria-expanded', 'false').next('.acc-panel').slideUp(250);
    if (!open) { $b.attr('aria-expanded', 'true').next('.acc-panel').slideDown(250); }
  });

  /* ---------- jQuery tabs (click + arrow keys) ---------- */
  $('.tablist').each(function () {
    var $list = $(this), $tabs = $list.find('button');
    function select($t) {
      $tabs.attr({ 'aria-selected': 'false', tabindex: '-1' });
      $t.attr({ 'aria-selected': 'true', tabindex: '0' }).trigger('focus');
      $list.parent().find('.tabpanel').removeClass('active').filter('#' + $t.attr('aria-controls')).addClass('active');
    }
    $tabs.on('click', function () { select($(this)); });
    $list.on('keydown', function (e) {
      var i = $tabs.index($tabs.filter('[aria-selected=true]'));
      if (e.key === 'ArrowRight') select($tabs.eq((i + 1) % $tabs.length));
      if (e.key === 'ArrowLeft') select($tabs.eq((i - 1 + $tabs.length) % $tabs.length));
    });
  });

  /* ---------- Modal (built with DOM methods; closes on Esc / overlay / close button) ---------- */
  var lastFocus = null;
  function openOverlay(box, cls) {
    lastFocus = document.activeElement;
    var ov = el('div', { 'class': 'overlay' }), c = el('button', { 'class': 'close', 'aria-label': 'Close' }, '\u00d7');
    box.classList.add(cls); box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.appendChild(c); ov.appendChild(box); document.body.appendChild(ov);
    function close() { ov.remove(); document.removeEventListener('keydown', onKey); if (lastFocus) lastFocus.focus(); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    c.addEventListener('click', close); ov.addEventListener('click', function (e) { if (e.target === ov) close(); });
    document.addEventListener('keydown', onKey); c.focus();
    return { close: close, overlay: ov };
  }
  function openModal(title, lines, link) {
    var box = el('div', { 'class': 'modal' });
    box.appendChild(el('h2', {}, title));
    lines.forEach(function (l) { box.appendChild(el('p', {}, l)); });
    if (link) box.appendChild(el('a', { 'class': 'btn', href: link.href }, link.text));
    openOverlay(box, 'modal');
  }

  /* ---------- Dynamic content: programmes (search / filter / sort) ---------- */
  var progBox = document.getElementById('programmes');
  if (progBox && window.PROGRAMMES) {
    var q = document.getElementById('search'), cat = document.getElementById('filter'), sort = document.getElementById('sort'), count = document.getElementById('count');
    var renderProg = function () {
      var term = q.value.trim().toLowerCase();
      var list = window.PROGRAMMES.filter(function (p) {
        return (cat.value === 'all' || p.cat === cat.value) && (p.name + ' ' + p.desc + ' ' + p.cat).toLowerCase().indexOf(term) > -1;
      }).sort(function (a, b) { return sort.value === 'price' ? a.rate - b.rate : sort.value === 'seats' ? b.seats - a.seats : a.name.localeCompare(b.name); });
      progBox.textContent = '';
      list.forEach(function (p) {
        var c = el('article', { 'class': 'card' });
        c.appendChild(el('span', { 'class': 'tag' }, p.cat));
        c.appendChild(el('h3', {}, p.name));
        c.appendChild(el('p', {}, p.desc));
        c.appendChild(el('p', { 'class': 'meta' }, 'Grades ' + p.grades + ' \u00b7 ' + p.days));
        c.appendChild(el('p', { 'class': 'meta' }, (p.rate ? rand(p.rate) + ' ' + p.unit : 'Free') + ' \u00b7 ' + (p.seats ? p.seats + ' places left' : 'Waiting list')));
        c.appendChild(el('a', { 'class': 'btn small', href: 'enquiry.html?programme=' + encodeURIComponent(p.id) }, 'Enquire'));
        progBox.appendChild(c);
      });
      count.textContent = list.length + ' programme' + (list.length === 1 ? '' : 's') + ' found';
      if (!list.length) progBox.appendChild(el('p', {}, 'No programmes match your search. Try a different keyword.'));
    };
    [q, cat, sort].forEach(function (e) { e.addEventListener('input', renderProg); });
    renderProg();
  }

  /* ---------- Dynamic content: events (search / filter / sort / details modal) ---------- */
  var evBody = document.getElementById('events-body'), upcoming = document.getElementById('upcoming');
  if (window.EVENTS && upcoming) {
    window.EVENTS.slice().sort(function (a, b) { return a.date.localeCompare(b.date); }).slice(0, 3).forEach(function (e) {
      var c = el('article', { 'class': 'card reveal visible' });
      c.appendChild(el('span', { 'class': 'tag' }, fmtDate(e.date)));
      c.appendChild(el('h3', {}, e.name)); c.appendChild(el('p', {}, e.desc)); c.appendChild(el('p', { 'class': 'meta' }, e.location));
      upcoming.appendChild(c);
    });
  }
  if (window.EVENTS && evBody) {
    var eq = document.getElementById('search'), et = document.getElementById('filter'), es = document.getElementById('sort'), ec = document.getElementById('count');
    var renderEv = function () {
      var term = eq.value.trim().toLowerCase();
      var list = window.EVENTS.filter(function (e) { return (et.value === 'all' || e.type === et.value) && (e.name + ' ' + e.desc + ' ' + e.location).toLowerCase().indexOf(term) > -1; })
        .sort(function (a, b) { return es.value === 'date-desc' ? b.date.localeCompare(a.date) : es.value === 'name' ? a.name.localeCompare(b.name) : a.date.localeCompare(b.date); });
      evBody.textContent = '';
      list.forEach(function (e) {
        var tr = el('tr');
        [fmtDate(e.date), e.name, e.desc, e.location].forEach(function (t, i) { tr.appendChild(el('td', i === 1 ? { style: 'font-weight:600' } : {}, t)); });
        var td = el('td'), b = el('button', { 'class': 'btn small', type: 'button', 'data-id': e.id, 'aria-label': 'Details for ' + e.name }, 'Details');
        td.appendChild(b); tr.appendChild(td); evBody.appendChild(tr);
      });
      ec.textContent = list.length + ' event' + (list.length === 1 ? '' : 's') + ' found';
      if (!list.length) { var r = el('tr'), c = el('td', { colspan: 5 }, 'No events match your search.'); r.appendChild(c); evBody.appendChild(r); }
    };
    [eq, et, es].forEach(function (e) { e.addEventListener('input', renderEv); });
    evBody.addEventListener('click', function (ev) { /* event delegation */
      var b = ev.target.closest('button[data-id]'); if (!b) return;
      var e = window.EVENTS.filter(function (x) { return x.id === b.dataset.id; })[0];
      openModal(e.name, [fmtDate(e.date) + ' \u00b7 ' + e.time, e.location, e.desc, 'Open to: ' + e.audience], { href: 'enquiry.html?programme=' + encodeURIComponent(e.programme), text: 'Register your interest' });
    });
    renderEv();
  }

  /* ---------- Gallery + lightbox ---------- */
  var gal = document.getElementById('gallery');
  if (gal && window.GALLERY) {
    window.GALLERY.forEach(function (g, i) {
      var b = el('button', { type: 'button', 'data-i': i, 'aria-label': 'Open image: ' + g.caption }), im = el('img', { src: g.src, alt: g.alt, width: 800, height: 600, loading: 'lazy' });
      b.appendChild(im); gal.appendChild(b);
    });
    gal.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-i]'); if (!b) return;
      var i = +b.dataset.i, n = window.GALLERY.length, box = el('div'), im = el('img'), cap = el('p'), nv = el('div', { 'class': 'lb-nav' });
      var prev = el('button', { 'class': 'btn small', type: 'button' }, '\u2190 Prev'), next = el('button', { 'class': 'btn small', type: 'button' }, 'Next \u2192');
      var show = function () { im.src = window.GALLERY[i].src; im.alt = window.GALLERY[i].alt; cap.textContent = window.GALLERY[i].caption + ' (' + (i + 1) + '/' + n + ')'; };
      var go = function (d) { i = (i + d + n) % n; show(); };
      prev.addEventListener('click', function () { go(-1); }); next.addEventListener('click', function () { go(1); });
      nv.appendChild(prev); nv.appendChild(cap); nv.appendChild(next); box.appendChild(im); box.appendChild(nv); show();
      var o = openOverlay(box, 'lightbox'); o.overlay.classList.add('lightbox');
      document.addEventListener('keydown', function k(ev) { if (!document.body.contains(o.overlay)) return document.removeEventListener('keydown', k); if (ev.key === 'ArrowLeft') go(-1); if (ev.key === 'ArrowRight') go(1); });
    });
  }

  /* ---------- Leaflet map (Sterkspruit) ---------- */
  if (document.getElementById('map') && window.L) {
    var pos = [-30.5167, 27.3667], map = L.map('map', { scrollWheelZoom: false }).setView(pos, 13);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
    L.marker(pos).addTo(map).bindPopup('<strong>TRIGEM Institute of Excellence</strong><br>Sterkspruit, Eastern Cape').openPopup();
  }

  /* ---------- Forms: client-side validation ---------- */
  function fieldError(f, msg) {
    var span = document.getElementById(f.id + '-error');
    f.setAttribute('aria-invalid', msg ? 'true' : 'false'); if (span) span.textContent = msg || '';
  }
  function checkField(f) {
    var msg = '';
    if (f.validity && !f.validity.valid) msg = (f.dataset.error && !f.validity.valueMissing) ? f.dataset.error : (f.validity.valueMissing ? 'This field is required.' : f.dataset.error || f.validationMessage);
    fieldError(f, msg); return !msg;
  }
  function validate(form) {
    var ok = true, first = null;
    $$('input:not(.hp),select,textarea', form).forEach(function (f) { if (!checkField(f)) { ok = false; first = first || f; } });
    if (first) first.focus(); return ok;
  }
  function wire(form) {
    $$('input:not(.hp),select,textarea', form).forEach(function (f) {
      f.addEventListener('blur', function () { checkField(f); });
      f.addEventListener('input', function () { if (f.getAttribute('aria-invalid') === 'true') checkField(f); });
    });
  }

  /* Enquiry form: AJAX fetch of programme pricing, then show cost + availability */
  var enq = document.getElementById('enquiry-form');
  if (enq) {
    wire(enq);
    var sel = document.getElementById('programme'), start = document.getElementById('start'), today = new Date(), max = new Date();
    max.setFullYear(max.getFullYear() + 1);
    var loc = function (d) { return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
    start.min = loc(today); start.max = loc(max);
    window.PROGRAMMES.forEach(function (p) { sel.appendChild(el('option', { value: p.id }, p.name)); });
    var pre = new URLSearchParams(location.search).get('programme'); if (pre) sel.value = pre;
    enq.addEventListener('submit', function (e) {
      e.preventDefault();
      if (enq.elements.hp.value || !validate(enq)) return;
      var out = document.getElementById('enquiry-result'), name = enq.elements.fullname.value.trim(), qty = +enq.elements.quantity.value;
      out.hidden = false; out.textContent = 'Checking availability\u2026';
      fetch('data/programmes.json').then(function (r) { if (!r.ok) throw new Error('bad'); return r.json(); })
        .catch(function () { return window.PROGRAMMES; }) /* fallback when opened from file:// */
        .then(function (list) {
          var p = list.filter(function (x) { return x.id === sel.value; })[0], total = p.rate * qty;
          out.textContent = '';
          out.appendChild(el('h3', {}, 'Thank you, ' + name.split(' ')[0] + '!'));
          out.appendChild(el('p', {}, 'Programme: ' + p.name + ' (Grade ' + enq.elements.grade.value + ', starting ' + fmtDate(enq.elements.start.value) + ').'));
          out.appendChild(el('p', {}, p.rate ? 'Estimated cost: ' + rand(total) + ' (' + qty + ' \u00d7 ' + rand(p.rate) + ' ' + p.unit + ').' : 'This programme is free of charge.'));
          out.appendChild(el('p', {}, p.seats > 0 ? 'Availability: ' + p.seats + ' places left. Sessions: ' + p.days + '.' : 'Availability: currently full \u2013 we have added you to the waiting list.'));
          out.appendChild(el('p', {}, 'A coordinator will contact you on ' + enq.elements.phone.value.trim() + ' or at ' + enq.elements.email.value.trim() + '.'));
          enq.reset(); out.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    });
  }

  /* Contact form: validate, compile an email, let the visitor send it to the recipient set below */
  var con = document.getElementById('contact-form');
  if (con) {
    wire(con);
    var RECIPIENT = 'info@trigem.org.za';
    con.addEventListener('submit', function (e) {
      e.preventDefault();
      if (con.elements.hp.value || !validate(con)) return;
      var subject = '[' + con.elements.topic.value + '] Message from ' + con.elements.fullname.value.trim();
      var body = 'Name: ' + con.elements.fullname.value.trim() + '\nEmail: ' + con.elements.email.value.trim() + '\nPhone: ' + (con.elements.phone.value.trim() || 'not supplied') + '\nType of message: ' + con.elements.topic.value + '\n\n' + con.elements.message.value.trim();
      var out = document.getElementById('contact-result'); out.hidden = false; out.textContent = '';
      out.appendChild(el('h3', {}, 'Your email is ready'));
      out.appendChild(el('p', {}, 'To: ' + RECIPIENT)); out.appendChild(el('p', {}, 'Subject: ' + subject));
      out.appendChild(el('pre', {}, body));
      out.appendChild(el('a', { 'class': 'btn', href: 'mailto:' + RECIPIENT + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body) }, 'Send email'));
      out.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }
  /* Donation form: validate, then thank the donor (no payment is processed in this demo) */
  var don = document.getElementById('donate-form');
  if (don) {
    wire(don);
    don.addEventListener('submit', function (e) {
      e.preventDefault();
      if (don.elements.hp.value || !validate(don)) return;
      var out = document.getElementById('donate-result'); out.hidden = false; out.textContent = '';
      out.appendChild(el('h3', {}, 'Thank you, ' + document.getElementById('donor-name').value.trim().split(' ')[0] + '!'));
      out.appendChild(el('p', {}, 'Your pledge of ' + rand(+document.getElementById('donation-amount').value) + ' has been recorded. We will email payment details to ' + document.getElementById('donor-email').value.trim() + '.'));
      don.reset();
    });
  }
})(jQuery);
