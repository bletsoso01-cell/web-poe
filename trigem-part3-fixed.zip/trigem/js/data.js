/* TRIGEM content data - rendered dynamically by main.js */
window.PROGRAMMES = [
 {
  "id": "maths-science-tutoring",
  "name": "Mathematics & Science Tutoring",
  "cat": "Tutoring",
  "grades": "8-12",
  "rate": 350,
  "unit": "per subject / month",
  "seats": 12,
  "days": "Mon & Wed 15:00-17:00",
  "desc": "Structured after-school lessons that strengthen subject knowledge and exam technique for Grades 8 to 12."
 },
 {
  "id": "foundation-literacy-numeracy",
  "name": "Foundation Literacy & Numeracy",
  "cat": "Tutoring",
  "grades": "4-7",
  "rate": 300,
  "unit": "per subject / month",
  "seats": 8,
  "days": "Tue & Thu 14:30-16:30",
  "desc": "Reading, writing and number skills for intermediate and senior primary learners."
 },
 {
  "id": "english-study-skills",
  "name": "English & Study Skills",
  "cat": "Tutoring",
  "grades": "4-12",
  "rate": 250,
  "unit": "per subject / month",
  "seats": 0,
  "days": "Fri 14:30-16:30",
  "desc": "Language support, note-taking, time management and study techniques."
 },
 {
  "id": "one-on-one-mentorship",
  "name": "One-on-One Mentorship",
  "cat": "Mentorship",
  "grades": "4-12",
  "rate": 200,
  "unit": "per month",
  "seats": 5,
  "days": "Sat 09:00-11:00",
  "desc": "A professional educator or volunteer mentor builds confidence, leadership and goals with your learner."
 },
 {
  "id": "group-mentorship-circles",
  "name": "Group Mentorship Circles",
  "cat": "Mentorship",
  "grades": "7-12",
  "rate": 120,
  "unit": "per month",
  "seats": 15,
  "days": "Sat 11:00-12:30",
  "desc": "Small peer groups that share experiences and practise teamwork and leadership."
 },
 {
  "id": "career-guidance-session",
  "name": "Career Guidance Session",
  "cat": "Careers",
  "grades": "10-12",
  "rate": 150,
  "unit": "per session",
  "seats": 20,
  "days": "By appointment",
  "desc": "Personal guidance on subject choices, bursaries, university and college applications."
 },
 {
  "id": "career-exhibition-pass",
  "name": "Career Exhibition Pass",
  "cat": "Careers",
  "grades": "8-12",
  "rate": 0,
  "unit": "",
  "seats": 60,
  "days": "See events page",
  "desc": "Free entry to our interactive exhibitions that showcase careers and higher education options."
 }
];
window.EVENTS = [
 {
  "id": "math-workshop",
  "name": "Math Workshop",
  "type": "Workshop",
  "date": "2026-11-14",
  "time": "09:00-12:00",
  "desc": "Interactive math skills workshop for Grades 7-9 learners.",
  "location": "TRIGEM Community Center",
  "audience": "Grades 7-9",
  "programme": "maths-science-tutoring"
 },
 {
  "id": "career-exhibition",
  "name": "Career Exhibition",
  "type": "Exhibition",
  "date": "2026-11-28",
  "time": "10:00-15:00",
  "desc": "Explore career options and meet professionals from various fields.",
  "location": "City Hall Auditorium",
  "audience": "Grades 8-12 and parents",
  "programme": "career-exhibition-pass"
 },
 {
  "id": "end-of-year-awards",
  "name": "End of Year Awards",
  "type": "Celebration",
  "date": "2026-12-05",
  "time": "14:00-17:00",
  "desc": "Celebrating learner achievements and success stories.",
  "location": "TRIGEM Auditorium",
  "audience": "Learners, parents and sponsors",
  "programme": "one-on-one-mentorship"
 },
 {
  "id": "science-seminar",
  "name": "Science Seminar",
  "type": "Workshop",
  "date": "2027-02-13",
  "time": "09:00-12:00",
  "desc": "Seminar on emerging science topics and research for Grades 10-12.",
  "location": "TRIGEM Learning Hall",
  "audience": "Grades 10-12",
  "programme": "maths-science-tutoring"
 },
 {
  "id": "mentorship-meetup",
  "name": "Mentorship Meetup",
  "type": "Networking",
  "date": "2027-03-20",
  "time": "10:00-13:00",
  "desc": "Networking event for mentors and mentees to share experiences.",
  "location": "Community Library",
  "audience": "Mentors and mentees",
  "programme": "group-mentorship-circles"
 }
];
window.GALLERY = [
 {
  "src": "https://storage.googleapis.com/a1aa/image/410c3fad-545f-4f75-95a9-aeb9b1bf42a4.jpg",
  "alt": "Students studying in a bright classroom, symbolising education and excellence",
  "caption": "Classroom learning"
 },
 {
  "src": "https://storage.googleapis.com/a1aa/image/72570a99-2266-4909-1a1e-e0e159c956fe.jpg",
  "alt": "A teacher helping a student with books and a chalkboard",
  "caption": "After-school tutoring"
 },
 {
  "src": "https://storage.googleapis.com/a1aa/image/c284e6ea-1029-4c1f-841c-95f2c81ec5c0.jpg",
  "alt": "Two people with speech bubbles and a lightbulb representing mentorship",
  "caption": "Mentorship"
 },
 {
  "src": "https://storage.googleapis.com/a1aa/image/ca3dbf7f-a8c2-4b6d-9ea9-1d795637fba3.jpg",
  "alt": "A presentation board with career icons",
  "caption": "Career exhibitions"
 },
 {
  "src": "https://storage.googleapis.com/a1aa/image/94b47c04-74f1-44a9-93e1-3fb6edbd0b05.jpg",
  "alt": "Learner in cap and gown proudly holding a graduation certificate",
  "caption": "Graduation success story"
 },
 {
  "src": "https://storage.googleapis.com/a1aa/image/4c05ded3-22b2-49b4-9986-a5bcca020ed1.jpg",
  "alt": "Learner receiving an award on stage while family and mentors applaud",
  "caption": "Awards success story"
 },
 {
  "src": "https://storage.googleapis.com/a1aa/image/f44da7a4-693a-43ca-56c2-3b1edae29b1e.jpg",
  "alt": "Learner studying with a mentor in a bright classroom",
  "caption": "Mentoring in action"
 }
];
